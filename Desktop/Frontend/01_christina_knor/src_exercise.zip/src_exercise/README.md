# Sample Sass Directory

###### To Run

First install Sass
```bash
gem install sass
```

From the `sample-scss-project` directory, run:
```bash
sass --watch scss/:css/
```